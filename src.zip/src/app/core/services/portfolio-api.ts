import { HttpClient } from '@angular/common/http';
import { inject, Service } from '@angular/core';

export interface Project {
  id: number;
  caseId: string;
  title: string;
  description: string;
  status: string;
}

export interface ExperienceEntry {
  id: number;
  dateRange: string;
  title: string;
  description: string;
}

export interface Skill {
  id: number;
  category: string;
  name: string;
  proficiency: number;
}

@Service()
export class PortfolioApi {
     private http = inject(HttpClient);
  private baseUrl = 'http://localhost:5089/api';

  getProjects() {
    return this.http.get<Project[]>(`${this.baseUrl}/Projects`);
  }

  getExperience() {
    return this.http.get<ExperienceEntry[]>(`${this.baseUrl}/Experience`);
  }

  getSkills() {
    return this.http.get<Skill[]>(`${this.baseUrl}/Skills`);
  }
  
}
