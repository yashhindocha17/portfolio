// import { Component, ElementRef, ViewChild, AfterViewInit, HostListener } from '@angular/core';
// import WebGLFluidEnhanced from 'webgl-fluid-enhanced';

// @Component({
//   selector: 'app-fluid-bg',
//   standalone: true,
//   imports: [],
//   template: `<div #fluidContainer style="position:fixed;top:0;left:0;width:100vw;height:100vh;z-index:0;pointer-events:none;"></div>`
// })
// export class FluidBg implements AfterViewInit {
//   @ViewChild('fluidContainer') containerRef!: ElementRef<HTMLDivElement>;

//   private simulation!: WebGLFluidEnhanced;
//   private colors = ['#3FE0A5', '#F0B94A', '#2B7FE0'];
//   private lastX = 0;
//   private lastY = 0;
//   private lastSplatTime = 0;

//   @HostListener('document:mousemove', ['$event'])
//   onMouseMove(e: MouseEvent) {
//     if (!this.simulation) return;

//     const now = performance.now();
//     if (now - this.lastSplatTime < 60) return;
//     this.lastSplatTime = now;

//     const dx = (e.clientX - this.lastX) * 2;
//     const dy = (e.clientY - this.lastY) * 2;
//     const color = this.colors[Math.floor(Math.random() * this.colors.length)];
//     this.simulation.splatAtLocation(e.clientX, e.clientY, dx, dy, color);
//     this.lastX = e.clientX;
//     this.lastY = e.clientY;
//   }

//   ngAfterViewInit() {
//     const el = this.containerRef.nativeElement;
//     this.simulation = new WebGLFluidEnhanced(el);
//     this.simulation.setConfig({
//       backgroundColor: '#07090C',
//       hover: false,
//       bloom: false,
//       colorful: false,
//       densityDissipation: 5,
//       velocityDissipation: 3,
//       brightness: 0.35
//     });
//     this.simulation.start();
//   }
// }

import { Component, ElementRef, ViewChild, AfterViewInit, HostListener } from '@angular/core';
import WebGLFluidEnhanced from 'webgl-fluid-enhanced';

@Component({
  selector: 'app-fluid-bg',
  standalone: true,
  imports: [],
  template: `<div #fluidContainer style="position:fixed;top:0;left:0;width:100vw;height:100vh;z-index:0;pointer-events:none;border:4px solid red;box-sizing:border-box;"></div>`
})
export class FluidBg implements AfterViewInit {
  @ViewChild('fluidContainer') containerRef!: ElementRef<HTMLDivElement>;

  private simulation!: WebGLFluidEnhanced;
  private colors = ['#3FE0A5', '#F0B94A', '#2B7FE0'];
  private lastX = 0;
  private lastY = 0;
  private lastSplatTime = 0;

  @HostListener('document:mousemove', ['$event'])
  onMouseMove(e: MouseEvent) {
    if (!this.simulation) return;
    const now = performance.now();
    if (now - this.lastSplatTime < 60) return;
    this.lastSplatTime = now;
    const dx = (e.clientX - this.lastX) * 2;
    const dy = (e.clientY - this.lastY) * 2;
    const color = this.colors[Math.floor(Math.random() * this.colors.length)];
    this.simulation.splatAtLocation(e.clientX, e.clientY, dx, dy, color);
    this.lastX = e.clientX;
    this.lastY = e.clientY;
  }

  ngAfterViewInit() {
    const el = this.containerRef.nativeElement;
    this.simulation = new WebGLFluidEnhanced(el);
    this.simulation.setConfig({
      backgroundColor: '#07090C',
      hover: false,
      bloom: false,
      colorful: false,
      densityDissipation: 5,
      velocityDissipation: 3,
      brightness: 0.35
    });
    this.simulation.start();
  }
}